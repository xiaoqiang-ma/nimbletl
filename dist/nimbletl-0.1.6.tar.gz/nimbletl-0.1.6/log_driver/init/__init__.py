LOG_DRIVE_DDL = """
    create table xiaoqiang(
        la int,
        haa varchar(20)
    );
"""