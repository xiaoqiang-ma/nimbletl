# NimbleTL

NimbleTL is a Python package to facilitate ETL development with a focus on quick and easy initialization of MySQL database tables.

## Installation

To install NimbleTL, run:

```bash
pip install nimbletl
